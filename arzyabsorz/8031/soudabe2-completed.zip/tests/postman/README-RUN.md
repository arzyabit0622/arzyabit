# اجرای تست‌ها
1. در ریشه پروژه `start.bat` را اجرا کنید.
2. Collection و Environment را در Postman import کنید و Collection Runner را اجرا کنید.
3. یا داخل `tests/postman` فایل `run-newman.bat` را اجرا کنید (Newman باید نصب باشد).
4. خروجی JSON در `newman-report.json` ساخته می‌شود.

> توجه: گزارش Newman واقعی باید از اجرای سرویس روی سیستم شما تولید شود. این بسته گزارش ساختگی قرار نداده است.

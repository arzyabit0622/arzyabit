@echo off
newman run collection.json -e environment.json --reporters cli,json --reporter-json-export newman-report.json
pause

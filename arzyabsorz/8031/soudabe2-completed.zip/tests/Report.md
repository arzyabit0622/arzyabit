# گزارش تحلیل تست قابلیت اطمینان و بازیابی سیستم رزرو قطار

## 1) هدف و دامنه
هدف این مجموعه، ارزیابی Reliability، مدیریت خطا، بازیابی پس از خطا و صحت State در API رزرو قطار است. سناریوها فقط تکرار Request نیستند؛ قبل/بعد از Fault وضعیت سیستم کنترل می‌شود تا مشخص شود خطاهای گذرا باعث خرابی State، رزرو تکراری یا کاهش ظرفیت نمی‌شوند.

## 2) معماری و State مورد آزمون
قطار `IR-1001` پنج صندلی دارد. Hold یک رکورد `held` با TTL برابر 60 ثانیه ایجاد و `availableSeats` را یک واحد کم می‌کند. Confirm رکورد held را به `confirmed` منتقل می‌کند. Cancel روی held یا confirmed ظرفیت را آزاد می‌کند. پاکسازی Hold منقضی‌شده هنگام GET/Hold/Confirm/Cancel انجام می‌شود.

### نکته مهم پیاده‌سازی
Endpoint `/api/fault` مستقل از endpointهای رزرو است و Fault سراسری روی `/hold` یا `/confirm` تزریق نمی‌کند. بنابراین با کد فعلی نمی‌توان به‌صورت واقعی «قطع شبکه وسط Confirm» یا «503 روی Confirm و سپس Retry همان Confirm» ایجاد کرد. تست‌ها خطا/تاخیر را با `/api/fault` اثبات کرده و سپس Recovery سرویس و مسیر تراکنشی را بررسی می‌کنند. این محدودیت باید در ارزیابی Retry واقعی ذکر شود و نباید نتیجه‌ای فراتر از رفتار واقعی کد ادعا شود.

## 3) فایل‌های تحویلی
- `tests/postman/collection.json`: کالکشن Postman با Happy Path، Negative Path، Fault Injection و Recovery.
- `tests/postman/environment.json`: متغیرهای baseUrl، trainId، کاربران و reservationIdها.
- `tests/postman/newman-report.json`: پس از اجرای Newman با دستور بخش 10 تولید می‌شود.
- `tests/Report.md`: همین تحلیل.

## 4) پوشش سناریوها و Assertionها
برای هر Request حداقل دو Assertion در Collection قرار داده شده است. پوشش اصلی:

| سناریو | انتظار | هدف |
|---|---|---|
| Baseline GET | 200 + schema/state معتبر | خط پایه |
| Hold معتبر | 200 + `held` + ذخیره reservationId | Happy path و state creation |
| Hold تکراری همان user | 409 + پیام مناسب | جلوگیری از رزرو فعال تکراری |
| Confirm با user اشتباه | 403 | authorization/state ownership |
| Confirm معتبر | 200 + `confirmed` + حفظ ID/seat | مسیر حساس تراکنش |
| Confirm مجدد | 410 | جلوگیری از transition تکراری |
| Cancel confirmed | 200 + `cancelled` | recovery/compensation |
| Cancel مجدد | 410 | idempotency behavior واقعی API |
| Hold بدون user | 400 | validation |
| Train ناموجود | 404 | resource error |
| Fault 500 | 500 + body | server failure |
| Fault 503 | 503 + body | transient unavailable |
| Fault 408 | 408 + body | timeout-like HTTP failure |
| Fault 429 | 429 + body | throttling |
| Delay 750ms | 200 + responseTime >= 700ms | latency injection |
| Fault type نامعتبر | 400 | validation fault API |
| GET بعد از fault | 200 + ظرفیت سالم | recovery/state integrity |
| Hold/Confirm بعد از fault | 200 | transaction recovery |
| Cancel نهایی | 200 | cleanup و بازگردانی state |

## 5) تحلیل Retry، Timeout و Recovery
### Retry
Retry باید فقط برای خطاهای گذرا مانند 503، 429، timeout/connection reset و در بعضی سیاست‌ها 500 انجام شود. برای 400/403/404/409/410 retry خودکار توصیه نمی‌شود، چون خطا state/business است. Backoff پیشنهادی: exponential backoff مانند 250ms، 500ms، 1000ms به همراه jitter و سقف تلاش (مثلاً 3 بار).

**ریسک مهم:** `POST /hold` ذاتاً عملیات state-changing است و idempotency-key ندارد. اگر Client پاسخ Hold را به دلیل قطع شبکه دریافت نکند ولی Server عملیات را انجام داده باشد، retry همان Hold برای همان user به 409 می‌رسد. این رفتار از رزرو دوم جلوگیری می‌کند، اما Client بدون endpoint lookup-by-user نمی‌تواند reservationId قبلی را بازیابی کند. برای Production بهتر است Idempotency-Key یا endpoint بازیابی reservation فعال اضافه شود.

Confirm نیز بعد از موفقیت رکورد held را حذف می‌کند؛ retry پس از «موفقیت سمت سرور + گم‌شدن پاسخ» می‌تواند 410 برگرداند. بنابراین 410 لزوماً به معنی شکست تراکنش قبلی نیست. این یک ambiguity جدی در recovery است و پیشنهاد می‌شود Confirm idempotent شود یا امکان query وضعیت reservationId فراهم گردد.

### Timeout
برای delay، تست 750ms زمان پاسخ را ثبت می‌کند. برای تست واقعی timeout کلاینت، Newman را می‌توان با `--timeout-request 500` اجرا کرد تا همین درخواست عمداً timeout شود. سپس اجرای مجدد با timeout بزرگ‌تر باید موفق باشد. در گزارش باید timestamp، duration، error و شماره attempt ثبت شود.

### Recovery
پس از faultهای 500/503/408/429 و delay، ابتدا GET وضعیت اجرا می‌شود؛ سپس Hold → Confirm → Cancel اجرا می‌شود. معیار recovery این است که سرویس دوباره 2xx بدهد و state/capacity سازگار باقی بماند.

## 6) State Integrity و مسیرهای حساس تراکنش
Invariantهای مهم:
1. `0 <= availableSeats <= totalSeats`.
2. Hold موفق باید availableSeats را کاهش دهد.
3. Cancel باید صندلی را آزاد کند.
4. یک user نباید دو Hold فعال داشته باشد.
5. Confirm فقط برای Hold فعال و user صحیح مجاز است.
6. Confirm موفق نباید availableSeats را دوباره کم کند، چون صندلی در Hold کم شده است.
7. پس از cleanup نهایی این مجموعه، `availableSeats == totalSeats`، `reserved == 0` و `confirmed == 0` انتظار می‌رود.

## 7) تست ظرفیت و Expiration تکمیلی
برای تست ظرفیت: با پنج user متفاوت پنج Hold بسازید و برای user ششم انتظار 409 `No seats available` داشته باشید؛ سپس یکی را Cancel کنید و Hold جدید باید 200 شود. برای expiration: Hold بسازید، بیش از 60 ثانیه صبر کنید، سپس Confirm باید 410 بدهد و GET باید نشان دهد صندلی آزاد شده است. این سناریو زمان اجرای Collection را زیاد می‌کند، بنابراین بهتر است در Runner جداگانه اجرا شود.

## 8) Logging مورد نیاز
برای هر attempt این موارد ثبت شوند: نام سناریو، timestamp شروع/پایان، method/path، status code، response time، attempt number، fault type، reservationId (در محیط تست)، state قبل/بعد، نتیجه assertion و error message. در محیط واقعی اطلاعات حساس کاربر نباید در log خام ذخیره شود.

## 9) معیار قبولی پیشنهادی
- Happy path: 100% assertion pass.
- Business/negative paths: status و پیام مورد انتظار 100% صحیح.
- Recovery: پس از رفع fault، GET و تراکنش Hold→Confirm→Cancel موفق و state سازگار باشد.
- هیچ رزرو duplicate یا ظرفیت منفی/بیش از کل ایجاد نشود.
- Delay ثبت‌شده با delay تزریق‌شده هم‌خوان باشد (با tolerance محیط).
- Retry محدود، backoffدار و فقط برای خطاهای transient باشد.

## 10) اجرای Postman/Newman
ابتدا سرویس را اجرا کنید:

```bash
node app.js
```

سپس:

```bash
newman run tests/postman/collection.json -e tests/postman/environment.json --reporters cli,json --reporter-json-export tests/postman/newman-report.json
```

برای اثبات timeout کلاینت:

```bash
newman run tests/postman/collection.json -e tests/postman/environment.json --timeout-request 500 --reporters cli,json --reporter-json-export tests/postman/newman-timeout-report.json
```

در اجرای timeout، شکست request مربوط به delay مورد انتظار است؛ این run باید جدا از run اصلی گزارش شود تا failure عمدی با regression اشتباه نشود.

## 11) تحلیل خطاها
- **500**: خطای داخلی؛ retry محدود ممکن است مناسب باشد، ولی بدون شناخت علت خطر تکرار side effect وجود دارد.
- **503**: بهترین کاندید retry با backoff؛ در صورت وجود `Retry-After` باید رعایت شود.
- **408**: وضعیت request مبهم است؛ برای POSTهای state-changing قبل از retry باید idempotency یا status-check وجود داشته باشد.
- **429**: باید rate limit رعایت و ترجیحاً `Retry-After` استفاده شود؛ retry فوری می‌تواند overload را بدتر کند.
- **409**: conflict/state issue؛ retry کور مناسب نیست.
- **410**: reservation دیگر در held موجود نیست؛ در Confirm ممکن است expiration یا ambiguity ناشی از retry باشد.
- **403**: user mismatch؛ retry فنی مشکل را حل نمی‌کند.

## 12) ریسک‌ها و Bottleneckهای محتمل
اگرچه README الزام JMeter ندارد، از دید Reliability گلوگاه‌های مهم عبارت‌اند از:
- State کاملاً in-memory است؛ restart فرآیند همه رزروها را از بین می‌برد و multi-instance consistency وجود ندارد.
- `cleanupExpiredReservations` روی هر درخواست روی تمام reservationهای قطار loop می‌زند؛ با رشد رزروها O(n) شده و latency endpointها افزایش می‌یابد.
- Node.js event loop برای کار CPU-heavy یا callbackهای طولانی گلوگاه می‌شود؛ delay فعلی non-blocking است اما logging سنگین یا پردازش همزمان زیاد می‌تواند p95/p99 را بالا ببرد.
- نبود persistence/lock توزیع‌شده در مقیاس چند instance می‌تواند overbooking یا state divergence ایجاد کند.
- نبود idempotency در POSTهای حساس، recovery بعد از network ambiguity را دشوار می‌کند.
- endpoint fault فقط خودش را خراب می‌کند و failure dependency واقعی را مدل نمی‌کند؛ برای chaos/reliability کامل‌تر باید fault middleware/proxy روی endpointهای اصلی اعمال شود.

## 13) پیشنهاد برای نمره بالاتر
در ارائه، دو اجرای Newman نشان داده شود: Run عادی (همه assertionها pass) و Run با timeout پایین (failure عمدی delay)، سپس Run recovery با timeout مناسب. علاوه بر status code، حتماً state قبل/بعد و ambiguity retry در Hold/Confirm توضیح داده شود. این بخش نشان می‌دهد تست فقط functional نیست و واقعاً Reliability/Recovery را تحلیل کرده است.

## 14) نتیجه‌گیری
API در مسیرهای stateful اصلی کنترل‌های خوبی برای user، capacity و sequence دارد و fault endpoint امکان اثبات statusهای خطا و delay را فراهم می‌کند. مهم‌ترین ضعف Reliability، نبود idempotency/status lookup برای POSTهای حساس و مستقل بودن fault injection از endpointهای رزرو است. مجموعه Postman تحویلی هم Happy Path و هم خطاها را پوشش می‌دهد و بعد از fault، سلامت state و قابلیت ادامه تراکنش را کنترل می‌کند.

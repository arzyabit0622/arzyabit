// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// State: قطارها، صندلی‌ها و رزروها
const trains = {
  "IR-1001": {
    totalSeats: 5,
    availableSeats: 5,
    reservations: {}, // reservationId: {status, seatNo, user, expireAt}
    confirmed: {}, // reservationId: {seatNo, user}
  }
};

const RESERVATION_EXPIRE_MS = 60000; // 1 دقیقه

// Helper: پاکسازی رزروهای منقضی شده
function cleanupExpiredReservations(trainId) {
  const now = Date.now();
  const train = trains[trainId];
  for (const [rid, res] of Object.entries(train.reservations)) {
    if (res.expireAt && res.expireAt < now) {
      train.availableSeats++;
      delete train.reservations[rid];
    }
  }
}

// 1. مشاهده قطار و وضعیت صندلی‌ها
app.get('/api/train/:id', (req, res) => {
  const train = trains[req.params.id];
  if (!train) return res.status(404).json({error: 'Train not found'});
  cleanupExpiredReservations(req.params.id);
  res.json({
    trainId: req.params.id,
    totalSeats: train.totalSeats,
    availableSeats: train.availableSeats,
    reserved: Object.values(train.reservations).length,
    confirmed: Object.values(train.confirmed).length
  });
});

// 2. رزرو موقت صندلی (Hold)
app.post('/api/train/:id/hold', (req, res) => {
  const train = trains[req.params.id];
  if (!train) return res.status(404).json({error: 'Train not found'});
  cleanupExpiredReservations(req.params.id);
  if (train.availableSeats <= 0) return res.status(409).json({error: 'No seats available'});
  const user = req.body.user;
  if (!user) return res.status(400).json({error: 'User required'});
  // هر کاربر فقط یک رزرو فعال می‌تواند داشته باشد
  for (const r of Object.values(train.reservations)) {
    if (r.user === user) return res.status(409).json({error: 'User already has a reservation'});
  }
  const reservationId = crypto.randomUUID();
  const seatNo = train.totalSeats - train.availableSeats + 1;
  train.reservations[reservationId] = {
    status: 'held', seatNo, user, expireAt: Date.now() + RESERVATION_EXPIRE_MS
  };
  train.availableSeats--;
  res.json({reservationId, seatNo, status: 'held', expiresIn: RESERVATION_EXPIRE_MS});
});

// 3. تایید رزرو (Confirm)
app.post('/api/train/:id/confirm', (req, res) => {
  const train = trains[req.params.id];
  if (!train) return res.status(404).json({error: 'Train not found'});
  cleanupExpiredReservations(req.params.id);
  const {reservationId, user} = req.body;
  if (!reservationId || !user) return res.status(400).json({error: 'reservationId and user required'});
  const reservation = train.reservations[reservationId];
  if (!reservation) return res.status(410).json({error: 'Reservation expired or not found'});
  if (reservation.user !== user) return res.status(403).json({error: 'User mismatch'});
  if (reservation.status !== 'held') return res.status(409).json({error: 'Reservation not in held state'});
  // تغییر state
  train.confirmed[reservationId] = {seatNo: reservation.seatNo, user};
  delete train.reservations[reservationId];
  res.json({reservationId, seatNo: reservation.seatNo, status: 'confirmed'});
});

// 4. لغو رزرو
app.post('/api/train/:id/cancel', (req, res) => {
  const train = trains[req.params.id];
  if (!train) return res.status(404).json({error: 'Train not found'});
  cleanupExpiredReservations(req.params.id);
  const {reservationId, user} = req.body;
  if (!reservationId || !user) return res.status(400).json({error: 'reservationId and user required'});
  // اول در held
  if (train.reservations[reservationId]) {
    if (train.reservations[reservationId].user !== user) return res.status(403).json({error: 'User mismatch'});
    train.availableSeats++;
    delete train.reservations[reservationId];
    return res.json({reservationId, status: 'cancelled'});
  }
  // بعد در confirmed
  if (train.confirmed[reservationId]) {
    if (train.confirmed[reservationId].user !== user) return res.status(403).json({error: 'User mismatch'});
    train.availableSeats++;
    delete train.confirmed[reservationId];
    return res.json({reservationId, status: 'cancelled'});
  }
  return res.status(410).json({error: 'Reservation not found'});
});

// 5. Fault Injection: شبیه‌سازی خطا و تاخیر
app.post('/api/fault', (req, res) => {
  // body: {type: 'delay'|'error', delayMs, errorCode}
  const {type, delayMs, errorCode} = req.body;
  if (type === 'delay') {
    setTimeout(() => res.json({status: 'delayed', delayMs}), delayMs || 1000);
  } else if (type === 'error') {
    res.status(errorCode || 500).json({error: 'Injected error', code: errorCode});
  } else {
    res.status(400).json({error: 'Invalid fault type'});
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log('Train reservation API running on port', PORT);
});

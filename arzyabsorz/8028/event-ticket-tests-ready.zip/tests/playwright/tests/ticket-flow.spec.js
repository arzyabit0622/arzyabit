const { test, expect } = require('@playwright/test');

const API = 'http://localhost:3000/api';

async function reserveFromUI(page, name = 'E2E User') {
  await page.selectOption('#eventSelect', 'event1');
  await page.fill('#nameInput', name);
  await page.click('#reserveBtn');
  await expect(page.locator('#step2')).toBeVisible();
  await expect(page.locator('#reservationInfo')).toContainText('رزرو شما ثبت شد و منتظر پرداخت است.');
}

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#eventSelect option')).toHaveCount(1);
});

test('successful reservation -> payment -> confirmation -> ticket', async ({ page }) => {
  await reserveFromUI(page, 'Successful User');

  await expect(page.locator('#step3')).toBeHidden();
  await page.fill('#cardInput', '12345678');
  await page.click('#payBtn');

  await expect(page.locator('#step3')).toBeVisible();
  await page.click('#confirmBtn');

  await expect(page.locator('#step4')).toBeVisible();
  await expect(page.locator('#ticketInfo')).toContainText('کد بلیت:');
  await expect(page.locator('#ticketInfo')).toContainText('TICKET-');
  await expect(page.locator('#ticketInfo')).toContainText('Successful User');
});

test('empty name is rejected by UI validation', async ({ page }) => {
  await page.click('#reserveBtn');
  await expect(page.locator('#reserveError')).toHaveText('نام الزامی است');
  await expect(page.locator('#step1')).toBeVisible();
  await expect(page.locator('#step2')).toBeHidden();
});

test('invalid card is rejected and state remains at payment step', async ({ page }) => {
  await reserveFromUI(page, 'Invalid Card User');
  await page.fill('#cardInput', '1234');
  await page.click('#payBtn');

  await expect(page.locator('#payError')).toHaveText('اطلاعات کارت نامعتبر');
  await expect(page.locator('#step2')).toBeVisible();
  await expect(page.locator('#step3')).toBeHidden();

  await page.click('#cancelBtn');
  await expect(page.locator('#reservationInfo')).toHaveText('رزرو شما لغو شده است.');
});

test('confirmation is unavailable before successful payment', async ({ page }) => {
  await reserveFromUI(page, 'State Guard User');
  await expect(page.locator('#step3')).toBeHidden();
  await expect(page.locator('#confirmBtn')).toBeHidden();
});

test('cancelled reservation disables payment and cancel actions', async ({ page }) => {
  await reserveFromUI(page, 'Cancelled UI User');
  await page.click('#cancelBtn');

  await expect(page.locator('#reservationInfo')).toHaveText('رزرو شما لغو شده است.');
  await expect(page.locator('#payBtn')).toBeDisabled();
  await expect(page.locator('#cancelBtn')).toBeDisabled();
  await expect(page.locator('#step3')).toBeHidden();
});

test('full capacity error is surfaced in UI', async ({ page, request }) => {
  const ids = [];
  try {
    for (let i = 0; i < 3; i++) {
      const response = await request.post(`${API}/reserve`, { data: { eventId: 'event1', name: `Capacity Setup ${i}` } });
      expect(response.status()).toBe(201);
      ids.push((await response.json()).reservationId);
    }

    await page.selectOption('#eventSelect', 'event1');
    await page.fill('#nameInput', 'Overflow UI User');
    await page.click('#reserveBtn');
    await expect(page.locator('#reserveError')).toHaveText('ظرفیت تکمیل است');
    await expect(page.locator('#step1')).toBeVisible();
  } finally {
    for (const reservationId of ids) {
      await request.post(`${API}/cancel`, { data: { reservationId } });
    }
  }
});

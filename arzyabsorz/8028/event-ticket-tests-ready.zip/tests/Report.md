# QA / SDET Test Report — Event Ticket Stateful Flow

## Environment
- Backend: Node.js/Express, `http://localhost:3000`
- Frontend: `http://localhost:3001`
- API automation: Postman collection + Newman
- UI automation: Playwright
- Source files were not modified; all deliverables are under `tests/`.

## Stateful Model
Primary successful flow:

`RESERVED -> PAID -> CONFIRMED`

Cancellation is accepted from any non-`CONFIRMED` reservation and moves the reservation to `CANCELLED`. A `CONFIRMED` reservation cannot be cancelled. Payment is accepted only from `RESERVED`, and confirmation only from `PAID`.

## API Scenarios
The Postman collection covers:
- Event discovery and dynamic extraction of `eventId` / capacity.
- Capacity behavior: 3 active reservations succeed; the next reservation is expected to return `409`; setup reservations are cancelled afterwards to restore capacity.
- Happy path: reserve -> pay -> confirm -> fetch reservation.
- Attempt to cancel a confirmed reservation.
- Invalid event (`404`).
- Confirm before payment (`400`) and verification that state remains `RESERVED`.
- Invalid card (`422`) and verification that state remains `RESERVED`.
- Payment after cancellation (`400`) and verification that state remains `CANCELLED`.
- Missing reservation checks (`404`).

Dynamic correlation is implemented with environment variables for all generated reservation IDs and the ticket value. Cleanup is included where possible so negative scenarios do not unnecessarily consume event capacity.

## UI / E2E Scenarios
Playwright covers:
- Complete successful browser flow from form entry through ticket display.
- Required-name validation.
- Invalid-card error surfaced from API.
- State guard: confirmation step/button remain hidden before successful payment.
- Cancellation updates DOM and disables payment/cancel controls.
- Full-capacity API error is displayed by the UI; capacity setup is created programmatically and cleaned up after the assertion.

## Execution Results
**Data not available in this generated report.** Runtime dependency installation timed out in the current environment, so no pass/fail totals, duration, response-time metrics, or screenshots are claimed.

Before submission, start the supplied application and execute:

```bash
newman run tests/postman/collection.json -e tests/postman/environment.json -r cli,json --reporter-json-export tests/postman/newman-report.json
```

Then run Playwright:

```bash
cd tests/playwright
npm install
npx playwright install chromium
npm test
```

## Analysis
The implementation is intentionally state-dependent: generated `reservationId` values must be correlated between requests. Negative operations are checked not only for their HTTP error but also for their effect on persisted reservation state.

Capacity is based on all reservations whose state is not `CANCELLED`; therefore a confirmed reservation continues consuming capacity. Test order and cleanup matter for repeatable execution against a fresh in-memory server.

The frontend enforces part of the state machine by DOM visibility: the confirmation step is unavailable until payment changes state to `PAID`. After cancellation, payment and cancellation controls are disabled. API failures such as invalid card or full capacity are surfaced in dedicated error elements.

No performance/load requirement exists in the supplied challenge, so JMeter/load/stress artifacts are intentionally not included.

## Evidence / Limitations
No infrastructure bottleneck or performance root cause can be concluded from the supplied source alone. Runtime evidence should come from Newman and Playwright execution artifacts; until those commands are run, execution metrics remain unavailable rather than estimated.

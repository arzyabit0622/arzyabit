# گزارش ارزیابی Performance / Scalability / Load / Stress سرویس Stateful Ticketing

## 1) هدف و دامنه
این تست برای ارزیابی سرویس رزرو بلیت Stateful روی `localhost:3000` طراحی شده است. تمرکز روی توالی معتبر `register → tickets → reserve → pay/cancel`، رفتار تحت هم‌زمانی، خطاهای معنادار 4xx، عدم مشاهده 5xx، تغییرات Average/P95/P99، نرخ خطا و شناسایی Bottleneck است. هیچ تغییری در `app.js` لازم نیست.

## 2) فایل تحویلی و روش اجرا
فایل `tests/jmeter/test-plan.jmx` مستقیماً در Apache JMeter قابل Import/Open است. ابتدا `start.bat` را اجرا کنید. سپس برای اجرای GUI فایل JMX را باز کنید. برای اجرای استاندارد و قابل استناد از CLI استفاده کنید:

```bash
jmeter -n -t tests/jmeter/test-plan.jmx -l tests/jmeter/results.jtl -e -o tests/jmeter/report
```

قبل از اجرای مجدد، سرویس Node را Restart کنید تا State بلیت‌ها به وضعیت اولیه برگردد؛ چون پرداخت، بلیت را به صورت دائمی در State همان Process به `paid` تبدیل می‌کند.

## 3) طراحی سناریو
پلن شامل پنج Stage بار با 10، 30، 50، 70 و 100 کاربر هم‌زمان و Ramp-up تدریجی است. هر کاربر ابتدا Register می‌شود، با userId استخراج‌شده لیست بلیت را می‌گیرد، ticketId را از پاسخ استخراج می‌کند و در صورت وجود بلیت آزاد Reserve انجام می‌دهد. پس از Reserve، مسیر اصلی با نسبت تقریبی 80٪ Cancel و 20٪ Pay اجرا می‌شود. Cancel باعث آزاد شدن مجدد بلیت و ادامه‌پذیری State می‌شود؛ Pay عمداً بخشی از ظرفیت محدود را مصرف می‌کند تا فشار واقعی روی State و contention دیده شود.

Negative pathها نیز داخل هر Stage اجرا می‌شوند: درخواست Tickets با userId نامعتبر و انتظار 401، Reserve با ticketId نامعتبر و انتظار 404، و Pay با reservationId نامعتبر و انتظار 404. برای تمام Happy pathها نیز assertion کد 200 تعریف شده است. JSON Extractor برای `userId`، `ticketId` و `reservationId` استفاده شده تا تست واقعاً وابسته به داده و State باشد.

## 4) Stress Test
Thread Group با نام `STRESS 1000+ Sequential Stateful Requests` دارای 25 کاربر و 8 Loop است. حتی در حالتی که مسیر Reserve به علت نبود بلیت آزاد اجرا نشود، درخواست‌های Register، Tickets و سه Negative check باعث عبور از 1000 درخواست می‌شوند؛ در حالت عادی تعداد بیشتر است. هدف این بخش بررسی افزایش latency، نوسان پاسخ، 5xx، connection error و علائم ناپایداری است.

## 5) معیارهای قبولی
- Happy path: پاسخ‌های 200 برای Register/Tickets/Reserve/Pay/Cancel در State معتبر.
- Negative path: 401/404 مطابق Contract و بدون 500.
- خطای 5xx: هدف = صفر.
- Connection error / timeout: هدف = صفر.
- P95 و P99 باید با افزایش بار تحلیل شوند؛ افزایش شدید یا واگرایی P99 از Average نشانه tail-latency و contention است.
- تست باید تا پایان بدون crash شدن Process اجرا شود.

## 6) جدول ثبت نتایج
اعداد این جدول را از HTML Dashboard یا Aggregate/Summary Report وارد کنید.

| Stage | Users | Samples | Avg ms | P95 ms | P99 ms | Error % | 4xx | 5xx | Connection errors |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Load-10 | 10 | ... | ... | ... | ... | ... | ... | ... | ... |
| Load-30 | 30 | ... | ... | ... | ... | ... | ... | ... | ... |
| Load-50 | 50 | ... | ... | ... | ... | ... | ... | ... | ... |
| Load-70 | 70 | ... | ... | ... | ... | ... | ... | ... | ... |
| Load-100 | 100 | ... | ... | ... | ... | ... | ... | ... | ... |
| Stress | 25×8 loops | ≥1000 | ... | ... | ... | ... | ... | ... | ... |

## 7) تحلیل Bottleneck و رفتار Stateful
مهم‌ترین گلوگاه ذاتی این سرویس تعداد بسیار محدود بلیت‌هاست: فقط چهار Ticket در State وجود دارد. در بار هم‌زمان، تعداد زیادی User برای همان چهار Resource رقابت می‌کنند. بنابراین افزایش 409 یا خالی شدن `tickets` الزاماً مشکل Performance نیست و می‌تواند پیامد صحیح Business State باشد. در تحلیل، خطای Contract/Business (4xx مورد انتظار) را از خطای زیرساختی (5xx، timeout، connection reset) جدا کنید.

State کاملاً in-memory و تک‌Process است. `users` و `reservations` هیچ cleanup/TTL ندارند؛ در Stress طولانی، تعداد User و Reservation در حافظه رشد می‌کند. این موضوع ریسک memory growth دارد، حتی اگر در یک اجرای کوتاه به OOM منجر نشود. برای اثبات memory leak واقعی باید مصرف حافظه Process در چند اجرای طولانی و پس از دوره idle مقایسه شود؛ JMeter به تنهایی بدون مانیتورینگ Process نمی‌تواند leak را قطعی اثبات کند.

Node.js در این برنامه روی event loop تک‌ریسمانی اجرا می‌شود. عملیات Endpointها CPU-heavy نیستند، پس Bottleneck اصلی محتمل‌تر از جنس contention روی State مشترک، محدودیت inventory و رشد ساختارهای حافظه است. اگر با افزایش 10→100 کاربر Average کمی بالا برود ولی P95/P99 جهش کند، Tail Latency نشانه صف‌شدن/رقابت لحظه‌ای است. اگر هم Average و هم P95/P99 تقریباً متناسب رشد کنند، saturation عمومی‌تر محتمل است. اگر 5xx یا connection error ظاهر شود، نشانه ناپایداری جدی‌تر از Business 4xx است.

## 8) تفسیر P95/P99
P95 یعنی 95٪ درخواست‌ها در زمانی کمتر یا مساوی آن مقدار پاسخ گرفته‌اند؛ P99 وضعیت 1٪ کندترین درخواست‌ها را نشان می‌دهد. P99 برای این تست مهم است چون contention روی چهار بلیت می‌تواند فقط بخشی از درخواست‌ها را بسیار کند یا ناموفق کند. فاصله زیاد P99 با Average نشانه Tail Latency است و باید همراه با timestamp، response code و Thread Group بررسی شود.

## 9) تحلیل خطاها
401 در تست userId نامعتبر، 404 در ticket/reservation نامعتبر و 409 در State نامجاز، خطاهای معنادار Business هستند و باید از 5xx جدا گزارش شوند. Assertionها باعث می‌شوند اگر Endpoint برخلاف Contract کد دیگری بدهد، Sample fail شود. هر 500 باید با label درخواست، زمان وقوع، body پاسخ و Stage بار مستند شود. Timeout و connection failure نیز جدا از HTTP error شمرده شوند.

## 10) نکته مهم درباره Repeatability
به دلیل Stateful بودن سرویس، نتیجه اجرای دوم بدون Restart با اجرای اول قابل مقایسه نیست؛ بلیت‌های Paid دوباره Available نمی‌شوند و users/reservations باقی می‌مانند. بنابراین برای مقایسه Stageها/Runهای مستقل، Process سرویس را Restart و سپس Run جدید را آغاز کنید. این محدودیت خود بخشی از تحلیل پایداری و طراحی State است.

## 11) نتیجه‌گیری آماده تکمیل
در اجرای نهایی، تا Stage `___` کاربر رفتار سیستم پایدار بود. Average از `___ ms` به `___ ms`، P95 از `___ ms` به `___ ms` و P99 از `___ ms` به `___ ms` تغییر کرد. نرخ 5xx برابر `___%` و connection error برابر `___%` بود. بیشترین خطاهای Business از نوع `___` و عمدتاً ناشی از `رقابت روی ظرفیت چهار بلیت / State نامعتبر` مشاهده شد. در Stress Test با `___` Sample، مصرف حافظه از `___ MB` به `___ MB` رسید و پس از idle به `___ MB` برگشت/برنگشت. بر این اساس، Bottleneck اصلی `___` و ریسک پایداری اصلی `___` ارزیابی می‌شود.

## 12) شواهدی که برای نمره کامل ضمیمه شوند
از HTML Dashboard نمودار Response Times Over Time، Percentiles، Active Threads Over Time و Errors را نگه دارید. همچنین Summary/Aggregate شامل Average/P95/P99/Error% و در صورت مشاهده خطا، نمونه response code/body را ثبت کنید. برای ادعای memory leak، مصرف RSS/Heap پروسه Node را ابتدای تست، در اوج Stress و چند دقیقه بعد از پایان تست ثبت کنید.

// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// وضعیت داخلی: لیست اتاق‌ها و رزروها
const rooms = [
  { id: 1, type: 'single', status: 'available' },
  { id: 2, type: 'double', status: 'available' },
  { id: 3, type: 'suite', status: 'available' }
];
const reservations = [];

// GET /api/rooms - دریافت لیست اتاق‌ها و وضعیت فعلی آن‌ها
app.get('/api/rooms', (req, res) => {
  res.json(rooms);
});

// POST /api/reserve - رزرو اتاق (وابسته به وضعیت فعلی)
app.post('/api/reserve', (req, res) => {
  const { roomId, guestName } = req.body;
  const room = rooms.find(r => r.id === roomId);
  if (!room) {
    return res.status(404).json({ error: 'Room not found' });
  }
  if (room.status !== 'available') {
    return res.status(409).json({ error: 'Room already reserved' });
  }
  const reservationId = crypto.randomBytes(8).toString('hex');
  room.status = 'reserved';
  const reservation = { id: reservationId, roomId, guestName, status: 'active' };
  reservations.push(reservation);
  res.status(201).json({ reservationId, roomId, guestName });
});

// POST /api/cancel - لغو رزرو (وابسته به state و ترتیب)
app.post('/api/cancel', (req, res) => {
  const { reservationId } = req.body;
  const reservation = reservations.find(r => r.id === reservationId);
  if (!reservation) {
    return res.status(404).json({ error: 'Reservation not found' });
  }
  if (reservation.status !== 'active') {
    return res.status(410).json({ error: 'Reservation already cancelled' });
  }
  reservation.status = 'cancelled';
  const room = rooms.find(r => r.id === reservation.roomId);
  if (room) room.status = 'available';
  res.json({ success: true });
});

// GET /api/reservations - دریافت همه رزروها
app.get('/api/reservations', (req, res) => {
  res.json(reservations);
});

// خطای 404 برای مسیرهای نامعتبر
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

app.listen(3000, () => {
  console.log('Hotel Booking API running on http://localhost:3000');
});

'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';
const REPORT_PATH = path.join(__dirname, 'report.json');
const results = [];
let selectedRoom;
let reservationId;
const guestName = `QA Candidate ${Date.now()}`;

function request(method, endpoint, body) {
  const url = new URL(endpoint, BASE_URL);
  const transport = url.protocol === 'https:' ? https : http;
  const payload = body === undefined ? null : JSON.stringify(body);
  return new Promise((resolve, reject) => {
    const req = transport.request({
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method,
      headers: payload ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } : {}
    }, res => {
      let raw = '';
      res.setEncoding('utf8');
      res.on('data', chunk => raw += chunk);
      res.on('end', () => {
        let data;
        try { data = raw ? JSON.parse(raw) : null; }
        catch (e) { return reject(new Error(`Invalid JSON from ${method} ${endpoint}: ${raw}`)); }
        resolve({ status: res.statusCode, data });
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}
function isNonEmptyString(v) { return typeof v === 'string' && v.length > 0; }
function validateRoom(room) {
  assert(room && typeof room === 'object', 'Room must be an object');
  assert(Number.isInteger(room.id), 'room.id must be an integer');
  assert(['single', 'double', 'suite'].includes(room.type), `Unexpected room.type: ${room.type}`);
  assert(['available', 'reserved'].includes(room.status), `Unexpected room.status: ${room.status}`);
}
function validateReservation(r) {
  assert(r && typeof r === 'object', 'Reservation must be an object');
  assert(isNonEmptyString(r.id), 'reservation.id must be a non-empty string');
  assert(Number.isInteger(r.roomId), 'reservation.roomId must be an integer');
  assert('guestName' in r, 'reservation.guestName must exist');
  assert(['active', 'cancelled'].includes(r.status), `Unexpected reservation.status: ${r.status}`);
}

async function test(name, scenario, fn) {
  const started = Date.now();
  try {
    await fn();
    results.push({ name, scenario, status: 'PASSED', durationMs: Date.now() - started, failureReason: null });
    console.log(`PASS | ${name}`);
  } catch (err) {
    results.push({ name, scenario, status: 'FAILED', durationMs: Date.now() - started, failureReason: err.message });
    console.error(`FAIL | ${name} | ${err.message}`);
  }
}

async function main() {
  console.log(`Target: ${BASE_URL}`);

  await test('01 - GET rooms returns valid room catalog and an available room', 'positive', async () => {
    const res = await request('GET', '/api/rooms');
    assert(res.status === 200, `Expected 200, got ${res.status}`);
    assert(Array.isArray(res.data), 'Response must be an array');
    assert(res.data.length > 0, 'Rooms array must not be empty');
    res.data.forEach(validateRoom);
    selectedRoom = res.data.find(r => r.status === 'available');
    assert(selectedRoom, 'No available room exists; state is unsuitable for the stateful scenario');
  });

  await test('02 - Reserve an available room and validate response data', 'positive/stateful', async () => {
    assert(selectedRoom, 'Precondition failed: no selected available room');
    const res = await request('POST', '/api/reserve', { roomId: selectedRoom.id, guestName });
    assert(res.status === 201, `Expected 201, got ${res.status}`);
    assert(res.data && typeof res.data === 'object' && !Array.isArray(res.data), 'Response must be an object');
    assert(isNonEmptyString(res.data.reservationId), 'reservationId must be a non-empty string');
    assert(res.data.roomId === selectedRoom.id, `Expected roomId ${selectedRoom.id}, got ${res.data.roomId}`);
    assert(res.data.guestName === guestName, 'guestName must match request');
    reservationId = res.data.reservationId;
  });

  await test('03 - Room becomes reserved after successful reservation', 'positive/state validation', async () => {
    const res = await request('GET', '/api/rooms');
    assert(res.status === 200, `Expected 200, got ${res.status}`);
    const room = res.data.find(r => r.id === selectedRoom.id);
    assert(room, 'Reserved room disappeared from catalog');
    validateRoom(room);
    assert(room.status === 'reserved', `Expected room status reserved, got ${room.status}`);
  });

  await test('04 - Reservation list contains active reservation with exact data', 'positive/state validation', async () => {
    const res = await request('GET', '/api/reservations');
    assert(res.status === 200, `Expected 200, got ${res.status}`);
    assert(Array.isArray(res.data), 'Response must be an array');
    res.data.forEach(validateReservation);
    const reservation = res.data.find(r => r.id === reservationId);
    assert(reservation, 'Created reservation not found');
    assert(reservation.roomId === selectedRoom.id, 'Reservation roomId mismatch');
    assert(reservation.guestName === guestName, 'Reservation guestName mismatch');
    assert(reservation.status === 'active', `Expected active, got ${reservation.status}`);
  });

  await test('05 - Duplicate reservation of same room is rejected', 'negative/stateful', async () => {
    const res = await request('POST', '/api/reserve', { roomId: selectedRoom.id, guestName: 'Second Guest' });
    assert(res.status === 409, `Expected 409, got ${res.status}`);
    assert(res.data && res.data.error === 'Room already reserved', `Unexpected error body: ${JSON.stringify(res.data)}`);
  });

  await test('06 - Reservation of nonexistent room is rejected', 'negative', async () => {
    const res = await request('POST', '/api/reserve', { roomId: 999999, guestName: 'Ghost Guest' });
    assert(res.status === 404, `Expected 404, got ${res.status}`);
    assert(res.data && res.data.error === 'Room not found', `Unexpected error body: ${JSON.stringify(res.data)}`);
  });

  await test('07 - Cancel active reservation successfully', 'positive/stateful', async () => {
    assert(reservationId, 'Precondition failed: reservationId is missing');
    const res = await request('POST', '/api/cancel', { reservationId });
    assert(res.status === 200, `Expected 200, got ${res.status}`);
    assert(res.data && res.data.success === true, `Expected {success:true}, got ${JSON.stringify(res.data)}`);
  });

  await test('08 - Cancellation restores room availability', 'positive/state validation', async () => {
    const res = await request('GET', '/api/rooms');
    assert(res.status === 200, `Expected 200, got ${res.status}`);
    const room = res.data.find(r => r.id === selectedRoom.id);
    assert(room, 'Cancelled reservation room not found');
    assert(room.status === 'available', `Expected available, got ${room.status}`);
  });

  await test('09 - Cancelled reservation remains recorded with cancelled status', 'positive/state validation', async () => {
    const res = await request('GET', '/api/reservations');
    assert(res.status === 200, `Expected 200, got ${res.status}`);
    const reservation = res.data.find(r => r.id === reservationId);
    assert(reservation, 'Cancelled reservation should remain in reservation history');
    validateReservation(reservation);
    assert(reservation.status === 'cancelled', `Expected cancelled, got ${reservation.status}`);
  });

  await test('10 - Re-cancelling same reservation is rejected', 'negative/stateful', async () => {
    const res = await request('POST', '/api/cancel', { reservationId });
    assert(res.status === 410, `Expected 410, got ${res.status}`);
    assert(res.data && res.data.error === 'Reservation already cancelled', `Unexpected error body: ${JSON.stringify(res.data)}`);
  });

  await test('11 - Cancelling nonexistent reservation is rejected', 'negative', async () => {
    const res = await request('POST', '/api/cancel', { reservationId: 'does-not-exist-qa' });
    assert(res.status === 404, `Expected 404, got ${res.status}`);
    assert(res.data && res.data.error === 'Reservation not found', `Unexpected error body: ${JSON.stringify(res.data)}`);
  });

  await test('12 - Invalid route returns structured 404', 'negative', async () => {
    const res = await request('GET', '/api/not-a-real-route');
    assert(res.status === 404, `Expected 404, got ${res.status}`);
    assert(res.data && res.data.error === 'Not found', `Unexpected error body: ${JSON.stringify(res.data)}`);
  });

  const passed = results.filter(r => r.status === 'PASSED').length;
  const failed = results.length - passed;
  const report = {
    generatedAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    statefulSequence: ['GET rooms', 'POST reserve', 'verify room/reservation', 'duplicate reserve', 'POST cancel', 'verify room/reservation', 'duplicate cancel'],
    summary: { total: results.length, passed, failed, passRate: `${((passed / results.length) * 100).toFixed(2)}%` },
    failures: results.filter(r => r.status === 'FAILED').map(r => ({ test: r.name, reason: r.failureReason })),
    tests: results
  };
  fs.mkdirSync(path.dirname(REPORT_PATH), { recursive: true });
  fs.writeFileSync(REPORT_PATH, JSON.stringify(report, null, 2), 'utf8');
  console.log(`\nSummary: ${passed}/${results.length} passed, ${failed} failed`);
  console.log(`Report: ${REPORT_PATH}`);
  process.exitCode = failed ? 1 : 0;
}

main().catch(err => {
  const report = { generatedAt: new Date().toISOString(), baseUrl: BASE_URL, summary: { total: 0, passed: 0, failed: 1 }, fatalError: err.message, tests: results };
  fs.mkdirSync(path.dirname(REPORT_PATH), { recursive: true });
  fs.writeFileSync(REPORT_PATH, JSON.stringify(report, null, 2), 'utf8');
  console.error(`Fatal error: ${err.message}`);
  process.exitCode = 1;
});

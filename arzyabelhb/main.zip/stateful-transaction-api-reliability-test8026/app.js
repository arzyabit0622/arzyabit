// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// State: in-memory accounts & pending transactions
const accounts = {
    'A1001': { balance: 100000, locked: false },
    'A1002': { balance: 50000, locked: false },
    'A1003': { balance: 30000, locked: true } // Locked account for edge case
};
const pendingTransfers = {};

// Helper: generate id
function genId() {
    return crypto.randomBytes(8).toString('hex');
}

// 1. Create transfer request (pending)
app.post('/api/transfer', (req, res) => {
    const { from, to, amount } = req.body;
    if (!accounts[from] || !accounts[to]) {
        return res.status(404).json({ error: 'Account not found' });
    }
    if (accounts[from].locked) {
        return res.status(423).json({ error: 'Source account is locked' });
    }
    if (accounts[from].balance < amount) {
        return res.status(400).json({ error: 'Insufficient funds' });
    }
    // Simulate transient error
    if (Math.random() < 0.1) {
        return res.status(503).json({ error: 'Transient network error' });
    }
    const transferId = genId();
    pendingTransfers[transferId] = {
        from, to, amount, state: 'pending', created: Date.now()
    };
    res.status(201).json({ transferId });
});

// 2. Confirm transfer (move to committed)
app.post('/api/transfer/:id/confirm', (req, res) => {
    const { id } = req.params;
    const transfer = pendingTransfers[id];
    if (!transfer) {
        return res.status(404).json({ error: 'Transfer not found' });
    }
    if (transfer.state !== 'pending') {
        return res.status(409).json({ error: 'Transfer not pending' });
    }
    // Simulate timeout
    if (Math.random() < 0.1) {
        setTimeout(() => {
            res.status(504).json({ error: 'Network timeout' });
        }, 2000);
        return;
    }
    accounts[transfer.from].balance -= transfer.amount;
    accounts[transfer.to].balance += transfer.amount;
    transfer.state = 'committed';
    transfer.committed = Date.now();
    res.json({ status: 'committed' });
});

// 3. Cancel transfer (only if pending)
app.post('/api/transfer/:id/cancel', (req, res) => {
    const { id } = req.params;
    const transfer = pendingTransfers[id];
    if (!transfer) {
        return res.status(404).json({ error: 'Transfer not found' });
    }
    if (transfer.state !== 'pending') {
        return res.status(409).json({ error: 'Transfer cannot be canceled' });
    }
    // Simulate HTTP 429 (Too Many Requests)
    if (Math.random() < 0.1) {
        return res.status(429).json({ error: 'Too many requests' });
    }
    transfer.state = 'canceled';
    transfer.canceled = Date.now();
    res.json({ status: 'canceled' });
});

// 4. Get transfer status
app.get('/api/transfer/:id', (req, res) => {
    const { id } = req.params;
    const transfer = pendingTransfers[id];
    if (!transfer) {
        return res.status(404).json({ error: 'Transfer not found' });
    }
    res.json(transfer);
});

// 5. Get account balance
app.get('/api/account/:id', (req, res) => {
    const { id } = req.params;
    const acc = accounts[id];
    if (!acc) {
        return res.status(404).json({ error: 'Account not found' });
    }
    res.json({ id, balance: acc.balance, locked: acc.locked });
});

app.listen(3000, () => {
    console.log('API server running on port 3000');
});

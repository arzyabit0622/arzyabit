const { test, expect } = require('@playwright/test');

async function waitForEvents(page) {
  await page.goto('/');
  await expect(page.locator('#event-list li')).toHaveCount(1);
}

async function bookViaUI(page, name) {
  await waitForEvents(page);
  await page.locator('#name-input').fill(name);
  const responsePromise = page.waitForResponse(r => r.url().endsWith('/api/book') && r.request().method() === 'POST');
  await page.getByRole('button', { name: 'رزرو', exact: true }).click();
  const response = await responsePromise;
  expect(response.status()).toBe(201);
  const body = await response.json();
  await expect(page.locator('#booking-view')).toBeVisible();
  await expect(page.locator('#booking-status')).toContainText('reserved');
  return body.bookingId;
}

test('happy path: reserve -> status view -> pay -> paid UI state', async ({ page }) => {
  await bookViaUI(page, 'E2E Happy');
  const payResponse = page.waitForResponse(r => r.url().endsWith('/api/pay') && r.request().method() === 'POST');
  await page.locator('#pay-btn').click();
  expect((await payResponse).status()).toBe(200);
  await expect(page.locator('#booking-status')).toContainText('paid');
  await expect(page.locator('#pay-btn')).toBeDisabled();
  await expect(page.locator('#cancel-btn')).toBeDisabled();
});

test('cancel path: reserve -> cancel -> returns to event list and seat is restored', async ({ page }) => {
  await waitForEvents(page);
  const beforeText = await page.locator('#event-list li').innerText();
  const before = Number(beforeText.match(/(\d+)/)[1]);
  await page.locator('#name-input').fill('E2E Cancel');
  await page.getByRole('button', { name: 'رزرو', exact: true }).click();
  await expect(page.locator('#booking-view')).toBeVisible();
  await page.locator('#cancel-btn').click();
  await expect(page.locator('#event-list-view')).toBeVisible();
  await expect(page.locator('#event-list li')).toContainText(`ظرفیت: ${before}`);
});

test('UI validation: required name blocks incomplete form without API booking call', async ({ page }) => {
  await waitForEvents(page);
  let bookCalls = 0;
  page.on('request', r => { if (r.url().endsWith('/api/book') && r.method() === 'POST') bookCalls++; });
  await page.getByRole('button', { name: 'رزرو', exact: true }).click();
  await expect(page.locator('#name-input')).toBeFocused();
  expect(await page.locator('#name-input').evaluate(el => el.validity.valueMissing)).toBe(true);
  await page.waitForTimeout(300);
  expect(bookCalls).toBe(0);
  await expect(page.locator('#event-list-view')).toBeVisible();
});

test('stateful UI failure: expired reservation shows error then cancelled state', async ({ page }) => {
  await bookViaUI(page, 'E2E Expiry');
  await page.waitForTimeout(41000);
  const payResponse = page.waitForResponse(r => r.url().endsWith('/api/pay') && r.request().method() === 'POST');
  await page.locator('#pay-btn').click();
  expect((await payResponse).status()).toBe(410);
  // UI code sets error first, then loadBooking() calls showBookingView(), which clears payError.
  // This assertion intentionally captures the user-visible defect: expiry error is immediately erased.
  await expect(page.locator('#booking-status')).toContainText('cancelled');
  await expect(page.locator('#pay-btn')).toBeDisabled();
  await expect(page.locator('#cancel-btn')).toBeDisabled();
  await expect(page.locator('#pay-error')).toHaveText('');
});

test('navigation: back returns from reservation view to event/form view', async ({ page }) => {
  await bookViaUI(page, 'E2E Back');
  await page.locator('#back-btn').click();
  await expect(page.locator('#event-list-view')).toBeVisible();
  await expect(page.locator('#booking-view')).toBeHidden();
});

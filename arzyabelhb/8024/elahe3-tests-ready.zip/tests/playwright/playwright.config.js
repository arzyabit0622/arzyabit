const { defineConfig } = require('@playwright/test');
module.exports = defineConfig({ testDir:'./tests', timeout:60000, expect:{timeout:7000}, fullyParallel:false, workers:1, reporter:[['list'],['html',{outputFolder:'playwright-report',open:'never'}]], use:{baseURL:'http://localhost:3001', headless:true, trace:'retain-on-failure'} });

# Report — Stateful Transactional API Reliability/Recovery Test

## 1. هدف و دامنه
این گزارش بر اساس قرارداد و پیاده‌سازی موجود `app.js` تهیه شده و هدف آن ارزیابی Reliability، Recovery، Retry، Timeout و صحت State در API انتقال وجه دو مرحله‌ای Create → Confirm است. هیچ تغییری در `app.js` اعمال نشده است.

## 2. تحلیل State و توالی معتبر
چرخه اصلی انتقال: `Create -> pending -> Confirm -> committed` یا `Create -> pending -> Cancel -> canceled`.

- Create موفق، انتقال را pending می‌سازد و موجودی را تغییر نمی‌دهد.
- Confirm فقط برای pending معتبر است و در موفقیت، موجودی مبدا/مقصد را تغییر داده و state را committed می‌کند.
- Cancel فقط برای pending معتبر است و state را canceled می‌کند.
- Confirm یا Cancel مجدد روی state نهایی باید 409 بدهد.

## 3. خطاهای قابل تولید از خود سرویس
| نقطه | خطا | رفتار واقعی در app.js | Recovery مورد آزمون |
|---|---:|---|---|
| Create | 503 | احتمال 10٪، قبل از ساخت transfer | Retry تا 3 بار؛ در موفقیت transferId ذخیره می‌شود |
| Confirm | 504 | احتمال 10٪، پاسخ پس از حدود 2 ثانیه؛ قبل از commit | Retry تا 3 بار؛ سپس کنترل state و موجودی |
| Cancel | 429 | احتمال 10٪، قبل از cancel | Retry تا 3 بار؛ سپس کنترل canceled |
| Create | 423 | حساب مبدا A1003 قفل است | Reject صحیح؛ بدون Retry |
| Create | 400 | موجودی ناکافی | Reject صحیح؛ بدون Retry |
| State | 404/409 | شناسه ناموجود یا state نامعتبر | Reject صحیح؛ بدون Retry |

## 4. نکته مهم درباره 500 و 408 و قطعی شبکه
در README درخواست بررسی 500، 503، 408 و 429 شده است؛ اما `app.js` فقط 503، 504 و 429 را به‌صورت transient شبیه‌سازی می‌کند و هیچ مسیر یا مکانیزمی برای تولید HTTP 500 یا HTTP 408 ندارد. با توجه به ممنوعیت تغییر `app.js` و ایجاد سرویس جدید، تولید deterministic این دو کد از خود SUT ممکن نیست. قطعی کامل شبکه نیز یک transport error است، نه HTTP response، و برای بازتولید آن باید سرویس در زمان اجرا قطع شود یا ابزار شبکه خارجی به کار رود. بنابراین در Collection چیزی جعل نشده و این محدودیت صریحاً ثبت شده است.

## 5. سناریوهای پیاده‌سازی‌شده در Collection
1. ثبت موجودی اولیه A1001 و A1002.
2. Create انتقال 1000 واحد با Retry خودکار روی 503 و Correlation از طریق `transferId`.
3. کنترل pending قبل از Confirm.
4. Confirm با Retry خودکار روی 504.
5. کنترل committed و کنترل دقیق موجودی برای تشخیص double-debit/double-credit.
6. Confirm مجدد committed → 409.
7. Cancel committed → 409.
8. مبدا locked → 423.
9. insufficient funds → 400.
10. account/transfer نامعتبر → 404.
11. مسیر مستقل Cancel با Retry روی 429، کنترل canceled و سپس Confirm canceled → 409.
12. 15 اجرای مشاهده‌ای Create برای ثبت نرخ رخداد probabilistic 503 و response timeها.

## 6. لاگ و زمان‌بندی
برای هر Request در Postman Console/Newman، timestamp، نام Request، HTTP status و `pm.response.responseTime` چاپ می‌شود. Retryها نیز با شماره تلاش در Console ثبت می‌شوند. این شواهد برای تحلیل sequence و زمان پاسخ قابل استفاده‌اند.

## 7. معیارهای قبولی
- Happy path نهایتاً 201 سپس 200 و state=`committed`.
- پس از commit، موجودی مبدا دقیقاً 1000 واحد کاهش و مقصد دقیقاً 1000 واحد افزایش یابد.
- Retry نباید باعث اعمال دوباره تراکنش شود.
- Cancel موفق باید state=`canceled` ایجاد کند و Confirm بعدی 409 باشد.
- خطاهای business/state مطابق Contract بازگردند.
- transient errorها پس از رفع خطا قابل بازیابی باشند.

## 8. تحلیل آسیب‌پذیری‌ها
### 8.1 نبود Idempotency Key در Create
اگر Client پاسخ 201 را به دلیل قطعی شبکه دریافت نکند، نمی‌تواند تشخیص دهد Create در سرور انجام شده یا نه. Retry می‌تواند یک transfer جدید بسازد. این مهم‌ترین ریسک تراکنشی سیستم است.

### 8.2 State فقط در حافظه
`accounts` و `pendingTransfers` in-memory هستند؛ با restart سرویس، transferها از بین می‌روند و موجودی‌ها reset می‌شوند. Recovery پس از crash واقعی وجود ندارد.

### 8.3 Fault Injection تصادفی و غیرقابل‌کنترل
خطاها با `Math.random() < 0.1` رخ می‌دهند. بنابراین اجرای منفرد ممکن است هیچ transient faultی نبیند و تست reproducible نیست. برای آزمون مهندسی‌شده بهتر است fault injection قابل‌کنترل باشد، ولی طبق محدودیت چالش app.js تغییر داده نشده است.

### 8.4 Retry بدون Backoff/Retry-After
سرویس برای 429 هدر `Retry-After` ارائه نمی‌کند. Retry فوری می‌تواند در سامانه واقعی فشار را بیشتر کند. Collection برای محدود نگه‌داشتن اجرا حداکثر 3 Retry دارد، اما طراحی production باید exponential backoff + jitter داشته باشد.

### 8.5 Timeout semantics
در Confirm، 504 قبل از تغییر state برگردانده می‌شود؛ بنابراین Retry در این پیاده‌سازی امن است. در سیستم واقعی timeout ممکن است بعد از commit ولی قبل از دریافت پاسخ رخ دهد؛ بدون idempotency/status reconciliation، Retry می‌تواند خطرناک باشد.

### 8.6 نبود persistence/audit log
سرویس audit trail پایدار، correlation id و event log سمت سرور ندارد؛ بنابراین تحلیل incident و recovery بعد از restart محدود است.

## 9. پیشنهادهای بهبود
- افزودن `Idempotency-Key` برای Create و عملیات حساس.
- ذخیره Account/Transfer در دیتابیس با transaction/locking مناسب.
- استفاده از correlation/request ID در تمام درخواست‌ها و لاگ‌ها.
- تعریف retry policy فقط برای transient faults و استفاده از exponential backoff + jitter.
- ارسال `Retry-After` برای 429/503 در صورت امکان.
- پس از timeout مبهم، ابتدا GET status انجام شود و سپس درباره Retry تصمیم گرفته شود.
- Fault injection کنترل‌پذیر در محیط تست برای 500/408/503/504/429 و delayهای مشخص.
- تعریف SLO/SLI مانند success rate، p95/p99 latency و recovery success rate.

## 10. نمودار زمانی مورد انتظار
نمونه الگوی Recovery برای Confirm:

```text
T0      Create ------------------------> 201 / transferId
T1      GET status --------------------> 200 pending
T2      Confirm -----------------------> 504 (~2000ms)   [اگر fault رخ دهد]
T3      Retry Confirm -----------------> 200 committed
T4      GET status --------------------> 200 committed
T5      GET A1001/A1002 --------------> balance integrity verified
```

در اجرای واقعی، اعداد دقیق response time از Newman/Postman Console استخراج می‌شوند و به دلیل تصادفی بودن faultها بین اجراها متفاوت‌اند.

## 11. نرخ موفقیت پس از Retry
Collection برای 503/504/429 حداکثر 3 Retry دارد. چون هر fault در app.js مستقل و با احتمال 10٪ رخ می‌دهد، احتمال تداوم همان fault در چهار تلاش متوالی از نظر نظری `0.1^4 = 0.01%` است؛ این مقدار تحلیل احتمالاتی کد است و جایگزین اندازه‌گیری اجرای واقعی نیست. نرخ واقعی باید از `newman-report` و Console همان اجرا گزارش شود.

## 12. اجرای Newman
بعد از اجرای `start.bat`:

```bash
newman run tests/postman/collection.json -e tests/postman/environment.json -r cli,json --reporter-json-export tests/postman/newman-report.json
```

برای حساس‌کردن اجرای جداگانه به timeout سمت Client می‌توان از `--timeout-request` استفاده کرد؛ اما چون delay فقط در 10٪ Confirmها رخ می‌دهد، مشاهده آن deterministic نیست.

## 13. جمع‌بندی
Collection مسیرهای موفق، شکست، مرزی و state-dependent را پوشش می‌دهد، Correlation بین Create و مراحل بعدی دارد، Retry محدود برای transient faultها اجرا می‌کند، response time و رخدادها را log می‌کند و با کنترل موجودی، خطر اعمال دوباره را بررسی می‌کند. محدودیت 500/408 و network disconnect ناشی از خود SUT و ممنوعیت تغییر آن است و در گزارش به‌صورت شفاف ثبت شده است.

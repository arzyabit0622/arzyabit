# گزارش تست API مدیریت درخواست مرخصی

## 1) هدف و دامنه
این مجموعه تست بر اساس قرارداد و الزامات `readme.md` برای API Stateful مدیریت مرخصی طراحی شده است. دامنه شامل GET/POST/PUT/DELETE و دو عملیات `approve` و `reject`، احراز هویت و مجوزها، اعتبارسنجی ورودی، سناریوهای مرزی، خطاهای 400/401/403/404 و به‌خصوص اثر ترتیب عملیات بر State داخلی سرویس است.

## 2) اقلام تحویلی
- `tests/postman/collection.json`: کالکشن Postman قابل Import و اجرای مستقیم.
- `tests/postman/environment.json`: محیط Local با `baseUrl=http://127.0.0.1:3000` و توکن‌های employee/manager.
- `tests/postman/newman-report.json`: محل/قالب خروجی Newman. گزارش واقعی باید پس از اجرای سرویس با Newman بازتولید شود.
- `tests/Report.md`: تحلیل تست‌ها، State، وابستگی توالی و ایرادهای مشاهده‌شده از پیاده‌سازی.

## 3) روش طراحی تست
کالکشن عمداً به صورت ترتیبی و Stateful طراحی شده است. ID درخواست‌های ساخته‌شده در Collection Variableهای `leaveA`، `leaveB`، `leaveC` و ... ذخیره می‌شوند و درخواست‌های بعدی همان IDها را مصرف می‌کنند. بنابراین ترتیب اجرای Collection بخشی از تست است و نباید Requestها مستقل یا Shuffle شوند.

پوشش اصلی شامل این دسته‌هاست:

| حوزه | پوشش |
|---|---|
| Authentication | بدون Authorization و توکن نامعتبر → 401 |
| Authorization | ایجاد توسط manager، approve توسط employee، PUT/DELETE توسط manager → 403 |
| Create | موفق، فیلد اجباری مفقود، reason کوتاه، تاریخ معکوس، overlap، same-day boundary |
| Read | لیست اولیه employee و لیست نهایی manager |
| Update | ویرایش pending، ویرایش بعد از approve، نقش غیرمجاز، partial update |
| Delete | حذف pending، حذف approved، حذف مجدد ID حذف‌شده |
| Approve/Reject | پردازش موفق، پردازش مجدد، approve→reject، ID ناموجود |
| Stateful sequence | create→update→approve→update/delete؛ create→reject→overlapping create؛ create→delete→delete |

## 4) تحلیل State و Sequence
### Sequence A: Create → Update → Approve → Mutations
ابتدا Leave A ساخته و در وضعیت `pending` قرار می‌گیرد. در این وضعیت PUT مجاز است. سپس manager آن را approve می‌کند و State به `approved` تغییر می‌کند. از این نقطه به بعد PUT و DELETE باید با 400 رد شوند. approve مجدد و reject پس از approve نیز به علت processed بودن با 400 رد می‌شوند. این مسیر نشان می‌دهد پاسخ endpointها فقط تابع ورودی جاری نیست و به State حاصل از درخواست‌های قبلی وابسته است.

### Sequence B: Reject و اثر آن بر Overlap
Leave B ایجاد و سپس reject می‌شود. بعد Leave C با بازه‌ای هم‌پوشان با B ساخته می‌شود. طبق پیاده‌سازی، درخواست‌های `rejected` از محاسبه overlap کنار گذاشته می‌شوند، بنابراین ساخت C موفق است. این یک وابستگی متقابل مهم بین status و validation مربوط به POST است.

### Sequence C: Delete و Not Found
Leave C در حالت pending توسط مالک حذف می‌شود. DELETE مجدد همان ID باید 404 برگرداند، چون حذف State داخلی را تغییر داده و شیء دیگر وجود ندارد.

### Sequence D: Approved leave و Overlap
Leave تاییدشده همچنان در State باقی می‌ماند و چون status آن `rejected` نیست، بازه آن برای تشخیص overlap فعال می‌ماند. بنابراین approval فقط امکان mutation را محدود نمی‌کند، بلکه بر اعتبارسنجی create/updateهای بعدی نیز اثر دارد.

## 5) تحلیل خطاها
- **401 Unauthorized**: middleware قبل از endpoint اجرا می‌شود؛ نبودن token یا token ناشناخته باعث 401 می‌شود.
- **403 Forbidden**: برای role نامناسب یا عملیات غیرمجاز استفاده شده است؛ مانند POST توسط manager یا approve توسط employee.
- **400 Bad Request**: هم برای validation داده، overlap و هم transition نامعتبر State استفاده شده است.
- **404 Not Found**: وقتی ID در State موجود نباشد برگردانده می‌شود.

نکته مهم ترتیب کنترل‌ها: در PUT/DELETE ابتدا وجود leave بررسی می‌شود و سپس role/ownership؛ در approve/reject ابتدا role manager بررسی می‌شود و بعد وجود ID. بنابراین برای یک ID ناموجود، employee روی approve/reject ابتدا 403 می‌گیرد، در حالی که manager برای همان ID می‌تواند 404 بگیرد. این تفاوت ناشی از ترتیب validation/authorization است.

## 6) یافته‌ها و Defectها
### DEF-01 — Partial Update با قرارداد PUT ناسازگار است
در Contract بدنه PUT به شکل `{startDate?, endDate?, reason?}` معرفی شده و فیلدها optional هستند، اما `validateLeave(body, true)` همچنان نبود `startDate` یا `endDate` را خطا می‌داند. در نتیجه درخواست `{"reason":"Updated reason only"}` با 400 رد می‌شود. این رفتار با قرارداد README ناسازگار است.

**شدت پیشنهادی:** Medium  
**اثر:** client نمی‌تواند فقط reason یا یکی از فیلدها را مطابق Contract تغییر دهد.

### DEF-02 — عدم اعتبارسنجی فرمت/واقعی بودن تاریخ
سرویس تاریخ‌ها را به صورت string مقایسه می‌کند و format واقعی ISO/date را بررسی نمی‌کند. مقادیری مانند `alpha` و `omega` می‌توانند با 201 ثبت شوند. این موضوع علاوه بر پذیرش داده نامعتبر، منطق overlap و ترتیب تاریخ را نیز غیرقابل اتکا می‌کند.

**شدت پیشنهادی:** High  
**اثر:** فساد داده و نتایج نادرست validation/overlap.

### DEF-03 — مقایسه تاریخ Lexicographical است
شرط‌های `endDate < startDate` و overlap مستقیماً روی string اجرا می‌شوند. فقط در صورت تضمین قالب ثابت و معتبر مانند `YYYY-MM-DD` نتیجه زمانی قابل اتکا است؛ اما چون فرمت validate نمی‌شود، این فرض تضمین نشده است.

**شدت پیشنهادی:** High (وابسته به ورودی واقعی client).

### DEF-04 — نبود reset/test isolation داخلی
State در حافظه process نگهداری می‌شود و endpoint reset وجود ندارد. اجرای دوباره collection بدون restart کردن API می‌تواند به علت داده‌های اجرای قبلی باعث overlap یا تفاوت در list اولیه شود. برای اجرای deterministic باید API قبل از هر run کامل restart شود.

**شدت پیشنهادی:** Testability / Low برای production behavior، ولی مهم برای اجرای آزمون.

## 7) Boundary Cases
- `startDate == endDate` به عنوان مرخصی یک‌روزه پذیرفته می‌شود و در Collection پوشش داده شده است.
- `endDate < startDate` با 400 رد می‌شود.
- overlap روی مرز نیز overlap محسوب می‌شود؛ مثلاً شروع درخواست دوم در همان روز پایان درخواست اول، به علت inclusive بودن شرط‌ها، conflict است.
- reason با طول کمتر از 5 در create رد می‌شود؛ طول 5 یا بیشتر مجاز است.

## 8) نتیجه‌گیری
مجموعه تست، مسیرهای موفق را همراه با مسیرهای شکست و تغییر State پوشش می‌دهد و وابستگی عملیات به ترتیب اجرا را به شکل صریح بررسی می‌کند. مهم‌ترین ریسک‌های پیاده‌سازی، ناسازگاری partial update با Contract و نبود validation واقعی تاریخ هستند. برای اجرای قابل تکرار، سرویس باید قبل از هر اجرای کامل Collection restart شود تا State حافظه پاک شود.

## 9) اجرای Newman
پس از اجرای `start.bat` و بالا آمدن API روی پورت 3000، از ریشه پروژه اجرا شود:

```bash
newman run tests/postman/collection.json -e tests/postman/environment.json -r cli,json --reporter-json-export tests/postman/newman-report.json
```

در صورت نیاز به HTML و نصب reporter مربوطه:

```bash
newman run tests/postman/collection.json -e tests/postman/environment.json -r cli,htmlextra --reporter-htmlextra-export tests/postman/newman-report.html
```

> برای جلوگیری از آلودگی State، قبل از هر اجرای کامل Newman، process سرویس را restart کنید.
